exports.handler = async (event) => {
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'TrustFix Demo Lambda',
      warning: 'INTENTIONALLY VULNERABLE - Do not use in production'
    })
  };
};
